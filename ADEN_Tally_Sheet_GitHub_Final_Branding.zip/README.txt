ADEN OPERATIONS — Tally Sheet Penerimaan Barang
Header menggunakan logo ADEN, warna merah, dan tulisan ANDALAN EKA NUSANTARA.
Header tetap khusus Tally Sheet (WAREHOUSE • GOODS RECEIVING • TALLY SHEET), tanpa tulisan DFR SCM.

Upload index.html dan aden-logo.jpg ke root repository GitHub.
Lalu Settings > Pages > Deploy from a branch > main > /(root) > Save.
Fitur: input penerimaan, selisih otomatis, ekspor CSV, cetak/PDF, dan penyimpanan lokal browser.
